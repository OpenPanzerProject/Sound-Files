Hi everybody.
This is my sound set for a Sherman tank using a R975 radial engine.
I included all the sounds you might want for having some fun with your tank.
I really hope you enjoy them. :)
Please feel free to use, modify and share at your will. Limit is your imagination!

TCB Recommended Settings:
- Transmission Engage Delay: 16 seconds (!)
- Sound level Engine/Effects/Track Overlay: 50% / 90% / 0%

Rad Schuhart   2019