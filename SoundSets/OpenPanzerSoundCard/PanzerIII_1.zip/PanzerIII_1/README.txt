Panzer III
Created by J�rgen Hammann

TCB Recommended Settings:
- Transmission Engage Delay: 5 seconds
- Engine On/Off Delay: 4 seconds


