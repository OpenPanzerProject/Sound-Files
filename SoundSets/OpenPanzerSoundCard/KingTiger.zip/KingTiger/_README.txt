King Tiger by Rad Schuhart - 2019

TCB Recommended Settings:
- Transmission Engage Delay: 27 seconds if using cold start sound (enstart1), 4 seconds if only using the hot start (enstart2).
  (If you only want the hot start sound, remove enstart1 and rename enstart2 to enstart1)
