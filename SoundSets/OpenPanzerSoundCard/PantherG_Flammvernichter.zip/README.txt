Panther G with Flammvernichter

TCB Recommended Settings:
- Transmission Engage Delay: 5 seconds
- Engine On/Off Delay: 7 seconds
- Acceleration Constraint: Level 12
- Deceleration Constraint: Level 8
- Sound level Engine/Effects: 50% / 50%

Created by J�rgen Hammann