Hi Fellow Tankers!

I made this soundset from the old very known Russian yt video starting up and revving an old SU-154

It needed several hours, coffees and brainfcks but I think its sounds cool. It is just engine sound, I made it for captured KV-1C so gun, crew and others should sounds different.

Hope you enjoy this

Rongyos