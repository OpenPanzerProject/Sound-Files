Famo Sd.Kfz.
Created by J�rgen Hammann
5/25/2018

TCB Recommended Settings:
- Transmission Engage Delay: 5 seconds
- Engine On/Off Delay: 3 seconds


