Sound set used for beta-testing the Open Panzer Sound Card

I am not saying these are the greatest sounds ever, but they are sufficient for testing. 

