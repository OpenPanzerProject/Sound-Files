German voices from Rad Schuhart. 

Note: Not all files may be in 44,100 16-bit WAV format, so conversion may be necessary. 